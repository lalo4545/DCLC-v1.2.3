# Generations

---

<aside>
☸️

# Quick Links

<aside>
▶️

[Dashboard](https://www.notion.so/TS4-Diffy-Cult-Challenge-28ceed3eb83180f5b0f0f4e031163a32?pvs=21)

</aside>

<aside>
♾️

[Generations](Generations%2028deed3eb8318072b52ecab4abfdfe75.md)

</aside>

<aside>
⚖️

[**Balances**](https://www.notion.so/Balances-28deed3eb83180499a96f5efdb2c127e?pvs=21)

</aside>

<aside>
📜

[**Rules/Lore**](https://www.notion.so/Rules-Lore-28deed3eb83180b1965afd46279ad482?pvs=21)

</aside>

<aside>
📌

[**Extra links**](https://www.notion.so/Extra-Links-28deed3eb831804ebeb3cf77a7f9699a?pvs=21)

</aside>

</aside>

<aside>

<aside>

<aside>

## Founding

</aside>

[ Gen 1 — The Believer ](Gen%201%20%E2%80%94%20The%20Believer%2028feed3eb831801789b8d0f1d475d998.md)

[ Gen 2 — The Doubter](Gen%202%20%E2%80%94%20The%20Doubter%2028deed3eb83180348d31e839eac019d9.md)

[ Gen 3 — The Prophet](Gen%203%20%E2%80%94%20The%20Prophet%2028deed3eb831808c842ad022bf6f38cd.md)

</aside>

</aside>

<aside>

<aside>

<aside>

### [Pop-Corn Phase](https://www.notion.so/Pop-Corn-Phase-28deed3eb831803ab12fcb29428100f6?pvs=21)

</aside>

[ Gen 4 — The Opulent](Gen%204%20%E2%80%94%20The%20Opulent%2028deed3eb8318093afdef822359314b2.md)

[ Gen 5 — The Rebuilders](Gen%205%20%E2%80%94%20The%20Rebuilders%2028deed3eb83180b6a310d53e440e6250.md)

[💪 Gen 6 — The Exhibitors](%F0%9F%92%AA%20Gen%206%20%E2%80%94%20The%20Exhibitors%2028deed3eb831805d848aece43d88f501.md)

</aside>

</aside>

<aside>

<aside>

<aside>

## Late Stage

</aside>

[Gen 7 — The Outcast](Gen%207%20%E2%80%94%20The%20Outcast%2028deed3eb831807b885ed6767426dc99.md)

[Gen 8](Gen%208%2028deed3eb83180b9a2fde73e20aa2b3d.md)

[Gen 9](Gen%209%2028deed3eb83180558869ef56cc8c7f6a.md)

[Gen 10](Gen%2010%2028deed3eb8318060aad7d73a8af319d4.md)

</aside>

</aside>

Copy your current Generation on your Dashboard to keep track!

---
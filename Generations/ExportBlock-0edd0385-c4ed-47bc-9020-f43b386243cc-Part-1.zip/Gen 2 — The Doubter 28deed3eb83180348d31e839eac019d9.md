# Gen 2 — The Doubter

> A reincarnated Founder, now born into comfort. This generation seeks truth through science before rediscovering spirit.
> 
- As you are not the Leader this generation you can have an outside job without penalty.
    - You must still live with the leader and maintain all the groups through them

### Date of Creation

<aside>
<img src="https://www.notion.so/icons/calendar_gray.svg" alt="https://www.notion.so/icons/calendar_gray.svg" width="40px" /> May 19, 2025

</aside>

![Gen 2 Profile.png](Gen_2_Profile.png)

(add a profile Picture)

**General Personality:**

- **Vibe**
    - Over-educated and under-satisfied
    - The lab coat is armor
- **In CAS**
    - Smart Casuals with colors from Gen 1
        - tans and whites - faith lingering
- **Personality:**
    - skeptical but sentimental
        - argues with ghosts
- **In-world tone**
    - Runs experiments that look suspiciously like prayers

# Goals

- [ ]  Money
    - [ ]  Reach the top of the Science Career
        - [ ]  When finished, retire
- [ ]  Have the following traits
    - [ ]  Genius / Skeptical / Grouchy
- [ ]  Aspirations
    - [ ]  Wellness Guru or Zen Master after retirement
- [ ]  Faith Infrastructure
    - You must fill all three social groups entirely with your own followers
        - No sim may belong to more than one group.
        - If a member dies, replace them immediately to keep the faith.
    
    > Any open spots in the clubs count as +1 shadow point per week.
    > 
- Leaders may never hold traditional careers; their time belongs entirely to the creed and its followers
    - grow or craft essentials
    - YOU CANNOT SELL OUT OF INVENTORY!

<aside>
<img src="https://www.notion.so/icons/forward_gray.svg" alt="https://www.notion.so/icons/forward_gray.svg" width="40px" /> **C H A R A C T E R   B I O**

Name:

Nickname(s): 

Pronouns:

Age:

Birthday:

Sexuality:

Religion/beliefs:

Aspiration/Job: 

Current Location: 

Origin Location:

Role in story:

Background: 

Any other details :

</aside>

<aside>
<img src="https://www.notion.so/icons/playback-pause_gray.svg" alt="https://www.notion.so/icons/playback-pause_gray.svg" width="40px" /> **PLAYLIST**

</aside>

[https://www.notion.so](https://www.notion.so)

[https://www.notion.so](https://www.notion.so)

(link your SimsTree Here)

---

[](https://www.notion.so)

(Images can be replaced)

- Family Members:
    - Parents:
    - Sister(s):
    - Brother(s):
- Love interests:
    - 
    - 
- Enemies:
    - 
    - 
    - 
- Relationships:
    
    Friends:
    
    Partner:
    

<aside>
🔱

 **Navigation**

[Dashboard](https://www.notion.so/Gen-1-The-Believer-28deed3eb831804c8e46d7b9bf9765e3?pvs=21)

[Generations](Generations%2028deed3eb8318072b52ecab4abfdfe75.md)

[Balances](https://www.notion.so/Balances-28deed3eb83180499a96f5efdb2c127e?pvs=21)

[Extra Links](https://www.notion.so/Extra-Links-28deed3eb831804ebeb3cf77a7f9699a?pvs=21)

[Rules and Lore](https://www.notion.so/Rules-Lore-28deed3eb83180b1965afd46279ad482?pvs=21)

</aside>